
package beans;
    //Java beans es una clase que contiene atributos privados y tiene un metodo set y get por cada propiedad y contiene un constructor vacio
public class Rectangulo {
    private int base;
    private int altura;
    
    //se define metodos set y get
    public int getAltura(){
        return this.altura;
    }
    
    public void setAltura(int altura){
        this.altura = altura;
    }
    
    public int getBase(){
        return this.base;
    }
    
    public void setBase(int base){
        this.base = base;
    }
    
    public int getArea(){
        return this.base * this.altura;
    }
}
