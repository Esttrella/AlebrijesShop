/*
Autor: Leonel Alexis García Juárez
Fecha de creación:12 de Mayo 2022
Fecha de Actualización: 13 de Mayo de 2022
Descripción: Clase alumno
*/
package beans;

public class Alumno {
    private String nombre;
    private String matricula;
    private int edad;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
    
}
