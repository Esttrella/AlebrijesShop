/*
Autor: Leonel Alexis García Juárez
Fecha de creación:12 de mayo 2022
Fecha de Actualización: 13 de Mayo de 2022
Descripción: Clase Alumno
*/
package javaBean;

public class Alumno {
    private String nombre;
    private String hombre;

    public String getNombre() {
        return nombre;
    }


    public String isHombre() {
        return hombre;
    }

    public void setNombre(String nom) {
        nombre = nom;
    }
    
    public void setHombre(String valor) {
        hombre = valor;
    }
}
