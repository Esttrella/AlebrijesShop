/*
Autor: Leonel Alexis García Juárez
Fecha de creación:12 de mayo 2022
Fecha de Actualización: 13 de Mayo de 2022
Descripción: Crea pagina principal
*/

package controller;

import javaBean.Alumno;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class servlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        Alumno bean = new Alumno();
        bean.setNombre(request.getParameter("nombre"));
        bean.setHombre(request.getParameter("hombre"));
        out.println("Hola "+bean.getNombre()+" eres un "+bean.isHombre());
    }

}
